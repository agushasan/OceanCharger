"""
ocean_charger.py
================

Shared core for the Ocean Charger / Dogger Bank A case study.

Contains:
  - PARAMETERS: engineering and economic parameters
  - load_layout(): reads turbine and substation positions from CSV
  - tour_cost(): the routing sub-problem (TSP with battery + recharging)

This module is imported by solve.py and plot.py. It has no side effects.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np


# -----------------------------------------------------------------------------
# Parameters
# -----------------------------------------------------------------------------

@dataclass(frozen=True)
class Params:
    """Engineering and economic parameters for the case study."""

    # Vessel
    battery_kwh:        float = 6000.0
    soc_min_frac:       float = 0.20
    soc_max_frac:       float = 0.95
    energy_kwh_per_km:  float = 95.0
    service_energy_kwh: float = 250.0

    # Charging
    charger_power_kw:        float = 3000.0
    charger_capex_annual_eur: float = 850_000.0

    # Economics
    elec_price_eur_per_kwh: float = 0.08
    diesel_ref_eur_per_day: float = 14_000.0
    annual_op_days:         int   = 300

    # Operational vessel-time cost. The SOV's time has economic value:
    # hours spent transiting (including detours back to the substation to
    # recharge) are hours not spent servicing turbines, and on a
    # weather-limited day they directly shorten the achievable workload.
    # Travel distance is converted to time via a nominal in-field transit
    # speed, and priced at a marginal vessel-time rate (crew + consumables
    # + opportunity), well below a full charter day-rate. Setting
    # vessel_time_eur_per_hour = 0 recovers the original electricity-only
    # objective exactly.
    vessel_speed_kmh:         float = 20.0
    vessel_time_eur_per_hour: float = 1_500.0

    @property
    def usable_kwh(self) -> float:
        return self.battery_kwh * (self.soc_max_frac - self.soc_min_frac)

    @property
    def time_cost_eur_per_km(self) -> float:
        """Vessel-time cost incurred per km travelled (EUR/km)."""
        return self.vessel_time_eur_per_hour / self.vessel_speed_kmh


PARAMS = Params()  # default instance used throughout


# -----------------------------------------------------------------------------
# Layout loading
# -----------------------------------------------------------------------------

def load_layout(data_dir: str | Path):
    """Load turbine positions, substation position, and candidate list.

    Returns
    -------
    turbines : (N_t, 2) ndarray of (x_km, y_km)
    sub      : (2,)     ndarray
    cand_idx : (N_c,)   ndarray of 0-based turbine indices
    """
    data_dir = Path(data_dir)
    turbines = np.loadtxt(data_dir / "turbines.csv",
                          delimiter=",", skiprows=1)
    sub = np.loadtxt(data_dir / "substation.csv",
                     delimiter=",", skiprows=1)
    cand_idx = np.loadtxt(data_dir / "candidates.csv",
                          delimiter=",", skiprows=1, dtype=int)
    return turbines, sub, cand_idx


def build_matrices(turbines: np.ndarray, sub: np.ndarray,
                   p: Params = PARAMS):
    """Build node array and distance / energy matrices.

    Convention: node 0 = substation, nodes 1..N_t = turbines.
    """
    all_nodes = np.vstack([sub[None, :], turbines])
    D = np.linalg.norm(all_nodes[:, None, :] - all_nodes[None, :, :], axis=-1)
    E = D * p.energy_kwh_per_km
    return all_nodes, D, E


# -----------------------------------------------------------------------------
# Routing sub-problem
# -----------------------------------------------------------------------------

def tour_cost(task_nodes, open_chargers, D, E, p: Params = PARAMS):
    """
    Solve the SOV routing sub-problem for a given set of tasks and open
    chargers.

    The SOV starts and ends at node 0 (substation). It must visit every
    node in `task_nodes` (in any order) while keeping state-of-charge
    above the minimum reserve. Charging is permitted at any node in
    `open_chargers`; charging from the substation is also permitted on
    return (modelling the realistic case where the substation can host
    a charger as part of its grid tie-in).

    The routine: nearest-neighbour initial tour, 2-opt improvement on the
    task ordering, then a greedy charger-insertion pass that walks the
    route and inserts a charging stop whenever the SoC would otherwise
    drop below the safety margin. When a charging stop is required, the
    stop (an in-field charger or a return to the substation) is chosen to
    minimise the *integrated* operating cost of the detour -- electricity
    plus vessel time -- rather than detour distance alone. Because both
    cost terms are monotone in distance this still reduces to a
    shortest-detour choice, but the realised cost reported now reflects
    the full operating objective the route is optimised against.

    Returns
    -------
    dict with keys:
        infeasible    : bool
        total_dist_km : float
        total_kwh     : float
        elec_cost_eur : float   daily electricity cost
        time_cost_eur : float   daily vessel-time cost
        op_cost_eur   : float   daily operating cost = elec + time
        route         : list of node indices (the realised tour, with
                        charger stops inserted)
        n_charges     : int
    """
    open_chargers = set(open_chargers)
    safety = 0.05 * p.usable_kwh

    # --- Nearest-neighbour initial tour ---
    unvisited = set(task_nodes)
    current = 0
    route = [0]
    while unvisited:
        nxt = min(unvisited, key=lambda j: D[current, j])
        route.append(nxt)
        unvisited.remove(nxt)
        current = nxt
    route.append(0)

    # --- 2-opt improvement on the task ordering ---
    def route_dist(r):
        return sum(D[r[i], r[i + 1]] for i in range(len(r) - 1))

    improved = True
    while improved:
        improved = False
        for i in range(1, len(route) - 2):
            for j in range(i + 1, len(route) - 1):
                new_route = route[:i] + route[i:j + 1][::-1] + route[j + 1:]
                if route_dist(new_route) + 1e-9 < route_dist(route):
                    route = new_route
                    improved = True

    # --- Battery simulation with greedy charger insertion ---
    soc = p.usable_kwh
    augmented = [route[0]]
    i = 0
    n_charges = 0
    infeasible = False
    max_iter = 300
    it = 0

    while i < len(route) - 1 and it < max_iter:
        it += 1
        cur = route[i]
        nxt = route[i + 1]
        leg_e  = E[cur, nxt]
        serv_e = p.service_energy_kwh if nxt != 0 else 0.0

        # Minimum energy required after servicing nxt: reach some charger
        # or the base from nxt.
        from_nxt_options = [E[nxt, c] for c in open_chargers if c != nxt] \
                           + [E[nxt, 0]]
        from_nxt = min(from_nxt_options)
        needed = leg_e + serv_e + from_nxt + safety

        if soc >= needed:
            soc -= (leg_e + serv_e)
            augmented.append(nxt)
            i += 1
        else:
            # Need to charge. Consider every reachable charging option --
            # the open in-field chargers AND a return to the substation --
            # on equal footing, and pick the one whose recharge detour has
            # the lowest integrated operating cost (electricity + vessel
            # time). Both terms are proportional to detour distance, so the
            # score is the detour distance weighted by the per-km operating
            # cost; the substation is no longer merely a last-resort
            # fallback but a genuine competitor to in-field chargers.
            cost_per_km = (p.energy_kwh_per_km * p.elec_price_eur_per_kwh
                           + p.time_cost_eur_per_km)

            options = [c for c in open_chargers
                       if E[cur, c] + safety <= soc and c != cur]
            if cur != 0 and E[cur, 0] + safety <= soc:
                options.append(0)          # substation as a charging option

            if not options:
                infeasible = True
                break

            # detour distance = leg to the charging node + onward leg to nxt
            best_c = min(options,
                         key=lambda c: (D[cur, c] + D[c, nxt]) * cost_per_km)
            soc -= E[cur, best_c]
            soc = p.usable_kwh
            augmented.append(best_c)
            n_charges += 1
            route = [best_c] + route[i + 1:]
            i = 0

    if it >= max_iter:
        infeasible = True

    if infeasible:
        return {"infeasible": True, "total_dist_km": np.inf,
                "total_kwh": np.inf, "elec_cost_eur": np.inf,
                "time_cost_eur": np.inf, "op_cost_eur": np.inf,
                "route": None, "n_charges": 0}

    total_dist = route_dist(augmented)
    n_services = sum(1 for n in augmented if n in task_nodes)
    total_kwh = total_dist * p.energy_kwh_per_km \
                + p.service_energy_kwh * n_services

    elec_cost = total_kwh * p.elec_price_eur_per_kwh
    time_cost = total_dist * p.time_cost_eur_per_km
    op_cost   = elec_cost + time_cost

    return {"infeasible": False,
            "total_dist_km": total_dist,
            "total_kwh": total_kwh,
            "elec_cost_eur": elec_cost,
            "time_cost_eur": time_cost,
            "op_cost_eur": op_cost,
            "route": augmented,
            "n_charges": n_charges}
