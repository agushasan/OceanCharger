"""
solve.py
========

Solve the Ocean Charger / Dogger Bank A optimisation problem.

This is the strategic + operational solver:

  - Strategic stage (first stage):   enumerate charger configurations
                                     of size K = 0..K_max from the
                                     candidate set.
  - Operational stage (second stage): solve the SOV routing sub-problem
                                     (TSP + battery + recharging) for
                                     each configuration.

The first stage is solved by explicit enumeration. With |candidates| = 21
and K up to 5, that is C(21, 5) = 20,349 configurations -- tractable.
For larger problems, switch to a branch-and-bound formulation in
`scipy.optimize.milp` or a commercial solver; the routing sub-problem
itself is small enough that the heuristic is near-optimal.

Two analyses are available:

  - Single-day:    one task realisation, evaluate K = 0..K_max.
  - Multi-day:     S task realisations, evaluate K = 1 across all
                   candidates, rank by expected annual cost.

Usage:
    python solve.py [--data DIR] [--out DIR] [--scenarios N] [--seed N]
"""
from __future__ import annotations

import argparse
import csv
from itertools import combinations
from pathlib import Path

import numpy as np

from ocean_charger import (
    PARAMS, Params, load_layout, build_matrices, tour_cost,
)


# -----------------------------------------------------------------------------
# Single-day optimisation
# -----------------------------------------------------------------------------

def solve_single_day(task_nodes, cand_nodes, D, E,
                     K_max: int = 5, p: Params = PARAMS):
    """Enumerate K = 0..K_max and find the best charger configuration.

    The objective is the integrated annual cost: charger capital plus the
    annualised operating cost, where operating cost now includes both
    vessel electricity and vessel time (see ocean_charger.tour_cost).
    """
    results = {}
    for K in range(K_max + 1):
        best = None
        combos = [()] if K == 0 else combinations(cand_nodes, K)
        for combo in combos:
            res = tour_cost(task_nodes, set(combo) if K > 0 else set(),
                            D, E, p)
            if res["infeasible"]:
                continue
            annual_op    = res["op_cost_eur"]   * p.annual_op_days
            annual_elec  = res["elec_cost_eur"] * p.annual_op_days
            annual_time  = res["time_cost_eur"] * p.annual_op_days
            annual_capex = K * p.charger_capex_annual_eur
            total = annual_op + annual_capex
            if best is None or total < best["total"]:
                best = {
                    "K": K, "combo": list(combo),
                    "annual_op": annual_op,
                    "annual_elec": annual_elec,
                    "annual_time": annual_time,
                    "annual_capex": annual_capex,
                    "total": total,
                    "tour_km": res["total_dist_km"],
                    "total_kwh": res["total_kwh"],
                    "route": res["route"],
                    "n_charges": res["n_charges"],
                }
        results[K] = best
    return results


# -----------------------------------------------------------------------------
# Multi-day stochastic analysis
# -----------------------------------------------------------------------------

def solve_multi_day(scenarios, cand_nodes, D, E, turbines,
                    p: Params = PARAMS):
    """Evaluate K = 1 across all candidates and all scenarios."""
    summary = []
    daily_costs_by_turbine = {}

    for c in cand_nodes:
        daily_costs = []
        daily_dists = []
        for task_nodes in scenarios:
            res = tour_cost(task_nodes, {c}, D, E, p)
            if res["infeasible"]:
                daily_costs.append(np.nan)
                daily_dists.append(np.nan)
            else:
                daily_costs.append(res["op_cost_eur"])
                daily_dists.append(res["total_dist_km"])
        daily_costs = np.array(daily_costs)
        daily_dists = np.array(daily_dists)
        valid = ~np.isnan(daily_costs)
        if not valid.any():
            continue

        mean_daily = float(daily_costs[valid].mean())
        std_daily  = float(daily_costs[valid].std())
        p95_daily  = float(np.percentile(daily_costs[valid], 95))
        annual_total = mean_daily * p.annual_op_days \
                       + p.charger_capex_annual_eur

        turbine_idx = c - 1
        summary.append({
            "turbine": turbine_idx,
            "mean_daily": mean_daily,
            "std_daily": std_daily,
            "p95_daily": p95_daily,
            "mean_km": float(daily_dists[valid].mean()),
            "annual_total": annual_total,
            "x_km": float(turbines[turbine_idx, 0]),
            "y_km": float(turbines[turbine_idx, 1]),
        })
        daily_costs_by_turbine[turbine_idx] = daily_costs.tolist()

    summary.sort(key=lambda s: s["annual_total"])
    return summary, daily_costs_by_turbine


# -----------------------------------------------------------------------------
# CSV output
# -----------------------------------------------------------------------------

def write_outputs(results_single, summary_multi, daily_costs, tasks_idx,
                  out_dir):
    """Write all CSV outputs that the plotting scripts consume."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # costs_vs_k.csv
    with open(out_dir / "costs_vs_k.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["K", "capex_eur", "opex_eur", "total_eur",
                    "tour_km", "sites", "elec_eur", "time_eur"])
        for K, b in results_single.items():
            if b is None:
                w.writerow([K, 0, 0, 0, 0, "infeasible", 0, 0])
            else:
                sites = "+".join(str(c - 1) for c in b["combo"]) \
                        if b["combo"] else "none"
                w.writerow([K, f"{b['annual_capex']:.0f}",
                            f"{b['annual_op']:.0f}",
                            f"{b['total']:.0f}",
                            f"{b['tour_km']:.2f}", sites,
                            f"{b['annual_elec']:.0f}",
                            f"{b['annual_time']:.0f}"])

    # route_k1.csv and charger_k1.csv
    b1 = results_single.get(1)
    if b1 is not None:
        with open(out_dir / "route_k1.csv", "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["node_index"])
            for n in b1["route"]:
                w.writerow([n])

        with open(out_dir / "charger_k1.csv", "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["turbine_index"])
            w.writerow([b1["combo"][0] - 1])

    # tasks_single.csv
    with open(out_dir / "tasks_single.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["turbine_index"])
        for t in tasks_idx:
            w.writerow([t])

    # multiday_k1.csv
    if summary_multi:
        with open(out_dir / "multiday_k1.csv", "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["turbine_index", "mean_daily_eur", "std_daily_eur",
                        "p95_daily_eur", "mean_km", "annual_total_eur",
                        "x_km", "y_km"])
            for s in summary_multi:
                w.writerow([s["turbine"],
                            f"{s['mean_daily']:.2f}",
                            f"{s['std_daily']:.2f}",
                            f"{s['p95_daily']:.2f}",
                            f"{s['mean_km']:.2f}",
                            f"{s['annual_total']:.2f}",
                            f"{s['x_km']:.4f}",
                            f"{s['y_km']:.4f}"])

    # scenario_costs.csv — per-scenario daily costs for the robust optimum
    # and the single-day optimum, whichever those happen to be.
    robust_t = summary_multi[0]["turbine"] if summary_multi else None
    single_t = results_single[1]["combo"][0] - 1 \
               if results_single.get(1) is not None else None
    if (robust_t is not None and single_t is not None
            and robust_t in daily_costs and single_t in daily_costs
            and robust_t != single_t):
        with open(out_dir / "scenario_costs_pair.csv", "w", newline="") as f:
            w = csv.writer(f)
            w.writerow([f"t{robust_t}_eur", f"t{single_t}_eur"])
            for a, b in zip(daily_costs[robust_t], daily_costs[single_t]):
                w.writerow([f"{a:.2f}", f"{b:.2f}"])
        # Also write a meta file recording which turbines these are
        with open(out_dir / "scenario_pair_meta.csv", "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["robust_turbine", "single_day_turbine"])
            w.writerow([robust_t, single_t])


# -----------------------------------------------------------------------------
# Reporting
# -----------------------------------------------------------------------------

def print_single_day(results, p: Params):
    print(f"\n{'K':>3} {'Sites':<26} {'Capex':>12} {'Elec':>11} "
          f"{'Time':>11} {'Total':>12} {'Tour km':>9}")
    print("-" * 92)
    for K, b in results.items():
        if b is None:
            print(f"{K:>3}  INFEASIBLE")
            continue
        sites = ",".join(f"T{c - 1}" for c in b["combo"]) \
                if b["combo"] else "(substation only)"
        print(f"{K:>3} {sites:<26} {b['annual_capex']:>12,.0f} "
              f"{b['annual_elec']:>11,.0f} {b['annual_time']:>11,.0f} "
              f"{b['total']:>12,.0f} {b['tour_km']:>9,.1f}")
    print(f"\nDiesel reference: EUR {p.diesel_ref_eur_per_day * p.annual_op_days:,.0f}/yr")
    print(f"Vessel time priced at EUR {p.vessel_time_eur_per_hour:,.0f}/h, "
          f"speed {p.vessel_speed_kmh:.0f} km/h "
          f"(EUR {p.time_cost_eur_per_km:,.0f}/km).")


def print_multi_day(summary, n_top: int = 10):
    print(f"\nTop {n_top} robust K=1 candidates (multi-day expected cost):")
    print(f"{'Rank':>4} {'Turbine':>8} {'Mean €/d':>10} {'P95 €/d':>10} "
          f"{'Mean km':>9} {'Annual €':>12}")
    print("-" * 60)
    for rank, s in enumerate(summary[:n_top], 1):
        print(f"{rank:>4} {'T' + str(s['turbine']):>8} "
              f"{s['mean_daily']:>10,.0f} {s['p95_daily']:>10,.0f} "
              f"{s['mean_km']:>9,.1f} {s['annual_total']:>12,.0f}")


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[1])
    parser.add_argument("--data", default="../data",
                        help="directory containing input CSVs")
    parser.add_argument("--out", default="../data",
                        help="directory for output CSVs (default: --data)")
    parser.add_argument("--scenarios", type=int, default=50,
                        help="number of scenarios for multi-day (0 to skip)")
    parser.add_argument("--n-tasks", type=int, default=12,
                        help="tasks per day in single-day analysis")
    parser.add_argument("--K-max", type=int, default=5,
                        help="maximum K to enumerate")
    parser.add_argument("--seed", type=int, default=2025)
    args = parser.parse_args()

    print(f"Ocean Charger - Dogger Bank A")
    print(f"  data dir:  {args.data}")
    print(f"  output:    {args.out}")

    # Load
    turbines, sub, cand_idx = load_layout(args.data)
    all_nodes, D, E = build_matrices(turbines, sub)
    cand_nodes = [int(i + 1) for i in cand_idx]
    print(f"  {len(turbines)} turbines, {len(cand_nodes)} candidate sites")

    # Single-day
    rng = np.random.default_rng(args.seed)
    tasks_idx = sorted(rng.choice(len(turbines), size=args.n_tasks,
                                  replace=False).tolist())
    task_nodes = [int(i + 1) for i in tasks_idx]
    print(f"\nSingle-day: {args.n_tasks} tasks at turbines {tasks_idx}")
    results_single = solve_single_day(task_nodes, cand_nodes, D, E,
                                       K_max=args.K_max)
    print_single_day(results_single, PARAMS)

    # Multi-day
    summary_multi = None
    daily_costs = {}
    if args.scenarios > 0:
        rng_s = np.random.default_rng(12345)
        S = args.scenarios
        scenarios = []
        for _ in range(S):
            w = int(rng_s.integers(8, 16))
            ts = sorted(rng_s.choice(len(turbines), size=w,
                                     replace=False).tolist())
            scenarios.append([int(i + 1) for i in ts])
        print(f"\nMulti-day: {S} scenarios, workload 8-15 tasks/day")

        # Include the single-day winner in the candidate set so the pair
        # comparison (robust vs single-day) can be done across all scenarios.
        single_day_winner_node = (results_single[1]["combo"][0]
                                  if results_single.get(1) is not None
                                  else None)
        cand_multi = sorted(set(cand_nodes)
                            | ({single_day_winner_node}
                               if single_day_winner_node else set()))
        summary_multi, daily_costs = solve_multi_day(
            scenarios, cand_multi, D, E, turbines, PARAMS)
        print_multi_day(summary_multi, n_top=10)

    write_outputs(results_single, summary_multi, daily_costs,
                  tasks_idx, args.out)
    print(f"\nWrote CSVs to {args.out}/")


if __name__ == "__main__":
    main()
