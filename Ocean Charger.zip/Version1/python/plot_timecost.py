"""
plot_timecost.py
================

Break-even figure for the integrated-objective (vessel-time) analysis:

  fig_timecost_breakeven.png
      Total integrated annual cost of K=0 (substation only) and K=1 (one
      in-field charger) as a function of the vessel-time value c_time.
      The lines cross at the break-even rate; the realistic SOV charter
      band is shaded. Cost heights use the same *absolute* vessel-time
      objective as solve.py and the report (capex + electricity +
      N_op*(c_time/v)*tour_km), so the curves are consistent with Table 1
      and the cost-decomposition figure.

Reads costs_vs_k.csv (written by solve.py) and sweeps c_time
analytically from the two tour lengths.

Styling matches the project's plot.py.
"""
from __future__ import annotations

import csv
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt

from ocean_charger import PARAMS

# --- palette (matches plot.py) ---
CAPEX   = "#c75b2f"   # charger capital (orange)
ELEC    = "#3a7d7a"   # electricity (teal)
TIME    = "#4a5a6a"   # vessel time (slate)
DIESEL  = "#7a3a3a"
ROBUST  = "#2d6a4f"
SINGLE  = "#c75b2f"
BG      = "#fbfaf6"
GRID    = "#d8d4c8"


def setup_style():
    plt.rcParams.update({
        "font.family": "DejaVu Serif",
        "font.size": 10,
        "axes.titlesize": 13,
        "axes.labelsize": 11,
        "axes.edgecolor": "#2b2b2b",
        "axes.linewidth": 0.8,
        "figure.facecolor": "white",
        "axes.facecolor": BG,
        "savefig.facecolor": "white",
    })


def read_breakdown(path="costs_vs_k.csv"):
    rows = []
    with open(path) as f:
        for r in csv.DictReader(f):
            if r["sites"] == "infeasible":
                continue
            rows.append({
                "K": int(r["K"]),
                "sites": r["sites"],
                "tour_km": float(r["tour_km"]),
                "capex": float(r["capex_eur"]),
                "elec": float(r["elec_eur"]),
                "time": float(r["time_eur"]),
                "total": float(r["total_eur"]),
            })
    return rows



# -----------------------------------------------------------------------------
# Figure 2: break-even sensitivity to vessel-time value
# -----------------------------------------------------------------------------

def plot_breakeven(rows, p, out="fig_timecost_breakeven.png"):
    setup_style()
    fig, ax = plt.subplots(figsize=(9, 6))

    r0 = next(r for r in rows if r["K"] == 0)
    r1 = next(r for r in rows if r["K"] == 1)

    # Integrated annual cost as a function of c_time (EUR/vessel-hour),
    # using the ABSOLUTE vessel-time objective (no differential subtraction),
    # consistent with solve.py, Table 1 and the cost-decomposition figure:
    #   total(c_time) = capex + electricity + N_op * (c_time / v) * tour_km
    days = p.annual_op_days
    v = p.vessel_speed_kmh

    def total_of(r, ctime):
        capex = r["capex"]
        elec = r["elec"]
        time = r["tour_km"] / v * ctime * days
        return capex + elec + time

    ctime = np.linspace(0, 5500, 500)
    c0 = total_of(r0, ctime)
    c1 = total_of(r1, ctime)

    # break-even
    hours_saved_yr = (r0["tour_km"] - r1["tour_km"]) / v * days
    be = (r1["capex"] - (r0["elec"] - r1["elec"])) / hours_saved_yr

    ax.plot(ctime, c0 / 1e6, color=SINGLE, lw=2.4,
            label="K=0  (substation only)")
    ax.plot(ctime, c1 / 1e6, color=ROBUST, lw=2.4,
            label="K=1  (one in-field charger, T66)")

    # break-even marker
    be_cost = total_of(r0, be) / 1e6
    ax.axvline(be, color="#444", ls=":", lw=1.4)
    ax.plot([be], [be_cost], "o", color="#222", ms=7, zorder=6)
    ax.annotate(f"break-even\n\u2248 {be:,.0f} \u20ac/vessel-hour",
                xy=(be, be_cost), xytext=(be + 250, be_cost - 0.32),
                fontsize=9.5, fontweight="bold",
                arrowprops=dict(arrowstyle="->", color="#222", lw=1.3))

    # realistic charter band (40-60k/day over ~12 working hours)
    band_lo, band_hi = 40000 / 12, 60000 / 12
    ax.axvspan(band_lo, band_hi, color=ROBUST, alpha=0.10, zorder=0)
    ax.text((band_lo + band_hi) / 2, ax.get_ylim()[1] * 0.30,
            "realistic SOV\ncharter band", rotation=90,
            ha="center", va="center", fontsize=8.5, color=ROBUST)

    # chosen value marker
    cv = p.vessel_time_eur_per_hour
    ax.axvline(cv, color="#999", ls="-", lw=1.0, alpha=0.8)
    ax.text(cv, ax.get_ylim()[1] * 0.96, f"  chosen\n  {cv:,.0f} \u20ac/h",
            fontsize=8.5, color="#666", va="top")

    # shade which option wins
    ax.text(be * 0.45, total_of(r0, be * 0.45) / 1e6 + 0.15,
            "K=0 cheaper", color=SINGLE, fontsize=10, fontweight="bold",
            ha="center")
    ax.text(min(be * 2.4, 2600), total_of(r1, min(be * 2.4, 2600)) / 1e6 + 0.18,
            "K=1 cheaper", color=ROBUST, fontsize=10, fontweight="bold",
            ha="center")

    ax.set_xlabel("Value of vessel time, $c^{\\mathrm{time}}$ (\u20ac per vessel-hour)")
    ax.set_ylabel("Integrated annual cost (M\u20ac/yr)")
    ax.set_title("Break-even: when does an in-field charger pay for itself?",
                 fontweight="bold", pad=14)
    ax.grid(color=GRID, lw=0.7)
    ax.set_axisbelow(True)
    ax.set_xlim(0, 5500)
    ax.legend(loc="lower right", frameon=True, framealpha=0.95,
              edgecolor=GRID, fontsize=9.5)
    plt.tight_layout()
    plt.savefig(out, dpi=160, bbox_inches="tight")
    plt.close()
    print(f"  wrote {out}  (break-even {be:,.0f} EUR/vessel-hour)")


def main():
    rows = read_breakdown()
    p = PARAMS
    plot_breakeven(rows, p)


if __name__ == "__main__":
    main()
