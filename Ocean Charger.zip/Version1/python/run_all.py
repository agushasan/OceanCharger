"""
Code by Agus Hasan (Norwegian University of Science and Technology)
run_all.py
==========

End-to-end entry point: solve the optimisation and regenerate all figures.

Usage:
    python run_all.py            # solve + plot
    python run_all.py --plot     # plot only (uses existing CSVs)
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path
import time

HERE = Path(__file__).parent


def run(cmd):
    print(f"\n$ {' '.join(cmd)}")
    r = subprocess.run(cmd, cwd=HERE)
    if r.returncode != 0:
        sys.exit(r.returncode)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plot", action="store_true",
                        help="skip solving; just regenerate figures")
    parser.add_argument("--data", default="../data")
    parser.add_argument("--out",  default="../figures")
    parser.add_argument("--scenarios", type=int, default=50)
    args = parser.parse_args()

    t0 = time.time()

    if not args.plot:
        run([sys.executable, "solve.py",
             "--data", args.data, "--out", args.data,
             "--scenarios", str(args.scenarios)])

    run([sys.executable, "plot.py",
         "--data", args.data, "--out", args.out])

    print(f"\nAll done in {time.time() - t0:.1f}s.")


if __name__ == "__main__":
    main()
