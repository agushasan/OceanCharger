"""
plot.py
=======

Regenerate all five figures for the Ocean Charger / Dogger Bank A report.

Reads CSVs from --data and writes PNGs to --out. Requires only numpy,
matplotlib, and scipy (for ConvexHull).

Usage:
    python plot.py                     # uses ../data and ../figures
    python plot.py --data DIR --out DIR
    python plot.py --only fig_dogger_main  # one figure at a time
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Circle, Polygon
from matplotlib.lines import Line2D
import matplotlib.patheffects as pe
from scipy.spatial import ConvexHull


# -----------------------------------------------------------------------------
# Style
# -----------------------------------------------------------------------------

def setup_style():
    plt.rcParams.update({
        "font.family": "DejaVu Serif",
        "font.size": 10,
        "axes.titlesize": 12,
        "axes.labelsize": 10,
        "axes.edgecolor": "#2b2b2b",
        "axes.linewidth": 0.8,
        "axes.grid": False,
        "figure.facecolor": "white",
        "axes.facecolor": "#fbfaf6",
        "savefig.facecolor": "white",
    })


# Colour palette
SEA      = "#e8eef2"
LEASE    = "#dde6ec"
TURBINE  = "#4a5a6a"
CHARGER  = "#c75b2f"
SUB      = "#7a1f1f"
ROUTE    = "#1f3a4d"
TASK     = "#f0b840"
CAND     = "#888888"
ROBUST   = "#2d6a4f"
SINGLE   = "#c75b2f"
DIESEL   = "#7a3a3a"
OPEX     = "#3a7d7a"
TIMECOST = "#4a5a6a"


# -----------------------------------------------------------------------------
# Data loading
# -----------------------------------------------------------------------------

def load_data(data_dir: str | Path) -> dict:
    d = Path(data_dir)

    def load(name, **kwargs):
        return np.loadtxt(d / name, delimiter=",", skiprows=1, **kwargs)

    out = {
        "turbines": load("turbines.csv"),
        "sub":      load("substation.csv"),
        "cand":     load("candidates.csv", dtype=int),
        "tasks":    load("tasks_single.csv", dtype=int),
        "route":    load("route_k1.csv", dtype=int).flatten(),
        "charger":  int(load("charger_k1.csv", dtype=int)),
    }
    # costs_vs_k.csv has a string column, parse manually
    costs = []
    with open(d / "costs_vs_k.csv") as f:
        header = next(f).strip().split(",")  # header
        has_breakdown = "elec_eur" in header and "time_eur" in header
        for line in f:
            parts = line.strip().split(",")
            row = {
                "K": int(parts[0]),
                "capex": float(parts[1]),
                "opex": float(parts[2]),
                "total": float(parts[3]),
                "tour_km": float(parts[4]),
                "sites": parts[5],
            }
            if has_breakdown and len(parts) >= 8:
                row["elec"] = float(parts[6])
                row["time"] = float(parts[7])
            else:
                # older format: no split available; treat all opex as elec
                row["elec"] = float(parts[2])
                row["time"] = 0.0
            costs.append(row)
    out["costs_vs_k"] = costs

    # multi-day data
    if (d / "multiday_k1.csv").exists():
        out["multiday"] = load("multiday_k1.csv")
    if (d / "scenario_costs_pair.csv").exists():
        # Header has e.g. "t48_eur,t66_eur" — keep the names for labels
        with open(d / "scenario_costs_pair.csv") as f:
            header = f.readline().strip().split(",")
        out["scenarios"] = np.loadtxt(d / "scenario_costs_pair.csv",
                                       delimiter=",", skiprows=1)
        # Parse turbine indices from header (e.g. "t48_eur" -> 48)
        out["scenarios_labels"] = [int(h.split("_")[0][1:]) for h in header]
    return out


def lease_polygon(turbines: np.ndarray, expand_km: float = 0.8):
    """Convex hull of turbines, slightly expanded outward."""
    hull = ConvexHull(turbines)
    pts = turbines[hull.vertices]
    cen = pts.mean(axis=0)
    v = pts - cen
    vn = v / np.linalg.norm(v, axis=1, keepdims=True)
    return pts + expand_km * vn


# -----------------------------------------------------------------------------
# Figure 1: optimal K=1 layout and route
# -----------------------------------------------------------------------------

def fig_dogger_main(data, out_path):
    turbines = data["turbines"]; sub = data["sub"]
    cand = data["cand"]; tasks = data["tasks"]
    route = data["route"]; charger = data["charger"]
    k1 = next(r for r in data["costs_vs_k"] if r["K"] == 1)
    all_nodes = np.vstack([sub[None, :], turbines])

    fig, ax = plt.subplots(figsize=(14, 8))
    ax.set_facecolor(SEA)

    ax.add_patch(Polygon(lease_polygon(turbines), facecolor=LEASE,
                         edgecolor="#7a8b9a", linewidth=1.2, linestyle="--",
                         zorder=0))

    ax.scatter(turbines[:, 0], turbines[:, 1], s=55, c=TURBINE,
               marker="o", edgecolors="white", linewidths=1.0, zorder=3)

    for ci in cand:
        ax.add_patch(Circle(turbines[ci], 0.45, fill=False,
                            edgecolor=CAND, linewidth=1.0,
                            linestyle=":", zorder=2))

    for ti in tasks:
        ax.add_patch(Circle(turbines[ti], 0.65, fill=False,
                            edgecolor=TASK, linewidth=2.2, zorder=2.5))

    # Charger
    pt = turbines[charger]
    ax.scatter(*pt, s=320, c=CHARGER, marker="s",
               edgecolors="white", linewidths=1.6, zorder=4)
    ax.annotate(f"CHARGER\n(T{charger})", pt, xytext=(10, 10),
                textcoords="offset points",
                fontsize=10, fontweight="bold", color=CHARGER,
                path_effects=[pe.withStroke(linewidth=3, foreground="white")])

    # Substation
    ax.scatter(*sub, s=260, c=SUB, marker="v",
               edgecolors="white", linewidths=1.6, zorder=4)
    ax.annotate("OFFSHORE\nSUBSTATION", sub, xytext=(10, -25),
                textcoords="offset points",
                fontsize=9, fontweight="bold", color=SUB,
                path_effects=[pe.withStroke(linewidth=3, foreground="white")])

    # Route
    for i in range(len(route) - 1):
        a = all_nodes[route[i]]; b = all_nodes[route[i + 1]]
        ax.add_patch(FancyArrowPatch(a, b, arrowstyle="-|>",
                                     mutation_scale=10,
                                     color=ROUTE, linewidth=1.6,
                                     alpha=0.85, zorder=3.5))

    diesel = 4.2e6
    # The electrification headline is measured on the capital + electricity
    # subtotal: a diesel SOV incurs essentially the same transit time, so the
    # vessel-time term does not enter the diesel-vs-electric comparison.
    capex_elec = k1["capex"] + k1["elec"]
    savings = 100 * (diesel - capex_elec) / diesel
    total_kwh = k1["tour_km"] * 95 + 250 * len(tasks)

    legend_elems = [
        Line2D([0], [0], marker="o", color="w", markerfacecolor=TURBINE,
               markersize=9, label="Turbine (95 total)"),
        Line2D([0], [0], marker="o", color="w", markerfacecolor="none",
               markeredgecolor=TASK, markeredgewidth=2.2,
               markersize=11, label=f"Maintenance task ({len(tasks)} today)"),
        Line2D([0], [0], marker="o", color="w", markerfacecolor="none",
               markeredgecolor=CAND, linestyle=":", markeredgewidth=1.2,
               markersize=11, label="Candidate charger site"),
        Line2D([0], [0], marker="s", color="w", markerfacecolor=CHARGER,
               markersize=12, label="Optimal charger (K=1)"),
        Line2D([0], [0], marker="v", color="w", markerfacecolor=SUB,
               markersize=11, label="Offshore substation (SOV base)"),
        Line2D([0], [0], color=ROUTE, linewidth=1.8, label="SOV route"),
    ]
    ax.legend(handles=legend_elems, loc="upper right", framealpha=0.95,
              fontsize=9)
    ax.set_xlabel("East (km)"); ax.set_ylabel("North (km)")
    ax.set_title(f"Dogger Bank A — Optimal Charger Location (K=1)\n"
                 f"Charger at turbine T{charger} · Tour {k1['tour_km']:.0f} km · "
                 f"capex+electricity \u2212{savings:.0f}% vs diesel · "
                 f"integrated \u20ac{k1['total']/1e6:.2f}M/yr",
                 fontweight="bold")
    ax.set_xlim(-2, 35); ax.set_ylim(-2, 19); ax.set_aspect("equal")
    plt.tight_layout()
    plt.savefig(out_path, dpi=160, bbox_inches="tight")
    plt.close()
    print(f"  -> {out_path}")


# -----------------------------------------------------------------------------
# Figure 2: cost decomposition vs K
# -----------------------------------------------------------------------------

def fig_dogger_costs(data, out_path):
    costs = data["costs_vs_k"]
    diesel = 4.2

    fig, ax = plt.subplots(figsize=(10, 6))
    Ks      = [r["K"] for r in costs]
    capex_m = [r["capex"] / 1e6 for r in costs]
    elec_m  = [r["elec"]  / 1e6 for r in costs]
    time_m  = [r["time"]  / 1e6 for r in costs]
    total_m = [r["total"] / 1e6 for r in costs]
    sites   = [r["sites"] for r in costs]

    has_time = any(t > 1e-9 for t in time_m)

    ax.bar(Ks, capex_m, 0.6, color=CHARGER,
           label="Charger capex (annualised)",
           edgecolor="white", linewidth=1.2)
    ax.bar(Ks, elec_m, 0.6, bottom=capex_m, color=OPEX,
           label="Vessel electricity (opex)",
           edgecolor="white", linewidth=1.2)
    if has_time:
        bottom_te = [c + e for c, e in zip(capex_m, elec_m)]
        ax.bar(Ks, time_m, 0.6, bottom=bottom_te, color=TIMECOST,
               label="Vessel time (opex)",
               edgecolor="white", linewidth=1.2)

    ax.axhline(diesel, color=DIESEL, linestyle="--", linewidth=1.5,
               label=f"Diesel SOV reference (\u20ac{diesel:.1f}M/yr)")

    # mark the optimum K (minimum total)
    kbest = min(range(len(total_m)), key=lambda i: total_m[i]
                if total_m[i] > 0 else float("inf"))

    ymax = max(max(total_m), diesel)
    for x, t, lab in zip(Ks, total_m, sites):
        if t > 0:
            ax.text(x, t + ymax * 0.015, f"\u20ac{t:.2f}M", ha="center",
                    fontsize=9,
                    fontweight="bold" if x == Ks[kbest] else "normal")
            ax.text(x, -ymax * 0.05, lab.replace("+", ", "), ha="center",
                    fontsize=7.5, style="italic", color="#555")

    # Optimum annotation
    if total_m[kbest] > 0:
        ax.annotate("INTEGRATED OPTIMUM",
                    xy=(Ks[kbest], total_m[kbest]),
                    xytext=(Ks[kbest] + 0.7, total_m[kbest] + ymax * 0.16),
                    ha="center", fontsize=10, fontweight="bold",
                    color=ROBUST,
                    arrowprops=dict(arrowstyle="->", color=ROBUST, lw=1.5))
    # K=0 callout
    if total_m[0] > 0 and has_time:
        ax.annotate('K=0: substation-only\n(detour returns inflate\nvessel-time cost)',
                    xy=(0, total_m[0]), xytext=(0.0, total_m[0] + ymax * 0.18),
                    ha="center", fontsize=8.5, color="#555",
                    arrowprops=dict(arrowstyle="->", color="#555", lw=1))

    ax.set_xlabel("Number of in-field chargers K")
    ax.set_ylabel("Annual cost (\u20ac million)")
    subtitle = ("integrated objective: capex + electricity + vessel time"
                if has_time else "capex + electricity")
    ax.set_title("Dogger Bank A \u2014 Cost Decomposition vs. K\n"
                 f"95 turbines, 12 tasks/day \u2014 {subtitle}",
                 fontweight="bold")
    ax.set_xticks(Ks)
    ax.legend(loc="upper left", framealpha=0.95)
    ax.set_ylim(-ymax * 0.08, ymax * 1.30)
    ax.grid(axis="y", alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_path, dpi=160, bbox_inches="tight")
    plt.close()
    print(f"  -> {out_path}")


# -----------------------------------------------------------------------------
# Figure 3: multi-day map
# -----------------------------------------------------------------------------

def fig_multiday_map(data, out_path):
    if "multiday" not in data:
        print("  (skipped: no multiday data)")
        return
    turbines = data["turbines"]; sub = data["sub"]
    md = data["multiday"]
    # Identify single-day winner from charger_k1
    single_t = int(data["charger"])
    ti_col   = md[:, 0].astype(int)
    annual_m = md[:, 5] / 1e6
    xs       = md[:, 6]; ys = md[:, 7]

    fig, ax = plt.subplots(figsize=(14, 8))
    ax.set_facecolor(SEA)
    ax.add_patch(Polygon(lease_polygon(turbines), facecolor=LEASE,
                         edgecolor="#7a8b9a", linewidth=1.2, linestyle="--",
                         zorder=0))

    ax.scatter(turbines[:, 0], turbines[:, 1], s=30, c=TURBINE,
               alpha=0.35, edgecolors="none", zorder=2)

    ax.scatter(*sub, s=240, c=SUB, marker="v",
               edgecolors="white", linewidths=1.6, zorder=4)
    ax.annotate("SUBSTATION", sub, xytext=(8, -22),
                textcoords="offset points", fontsize=9, fontweight="bold",
                color=SUB,
                path_effects=[pe.withStroke(linewidth=3, foreground="white")])

    cmap = plt.cm.RdYlGn_r
    norm = plt.Normalize(vmin=annual_m.min(), vmax=annual_m.max())
    best_i = int(np.argmin(annual_m))
    best_t = int(ti_col[best_i])

    for i, ti in enumerate(ti_col):
        c = cmap(norm(annual_m[i]))
        ax.scatter(xs[i], ys[i], s=260, c=[c], marker="o",
                   edgecolors="black", linewidths=1.0, zorder=3)
        if i == best_i:
            ax.add_patch(Circle((xs[i], ys[i]), 1.4, fill=False,
                                edgecolor=ROBUST, linewidth=3.0, zorder=5))
            ax.annotate(f"ROBUST OPTIMUM\nT{ti} · €{annual_m[i]:.2f}M/yr",
                        (xs[i], ys[i]), xytext=(15, 15),
                        textcoords="offset points",
                        fontsize=10, fontweight="bold", color=ROBUST,
                        path_effects=[pe.withStroke(linewidth=3, foreground="white")])
        if ti == single_t and ti != best_t:
            single_rank = int(np.argsort(annual_m).tolist().index(i)) + 1
            ax.add_patch(Circle((xs[i], ys[i]), 1.0, fill=False,
                                edgecolor=SINGLE, linewidth=2.5,
                                linestyle="--", zorder=4.5))
            ax.annotate(f"Single-day optimum\nT{single_t} (rank {single_rank})",
                        (xs[i], ys[i]), xytext=(-90, -40),
                        textcoords="offset points",
                        fontsize=9, fontweight="bold", color=SINGLE,
                        path_effects=[pe.withStroke(linewidth=3, foreground="white")],
                        arrowprops=dict(arrowstyle="->", color=SINGLE, lw=1.2))

    sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm); sm.set_array([])
    cbar = plt.colorbar(sm, ax=ax, fraction=0.035, pad=0.02)
    cbar.set_label("Expected annual cost (€M)", fontsize=10)
    ax.set_xlabel("East (km)"); ax.set_ylabel("North (km)")
    ax.set_title("Dogger Bank A — Robust Charger Location (K=1)\n"
                 "Expected cost across 50 task realisations · workload 8–15 tasks/day",
                 fontweight="bold")
    ax.set_xlim(-2, 35); ax.set_ylim(-2, 19); ax.set_aspect("equal")
    plt.tight_layout()
    plt.savefig(out_path, dpi=160, bbox_inches="tight")
    plt.close()
    print(f"  -> {out_path}")


# -----------------------------------------------------------------------------
# Figure 4: distribution comparison + top-10 ranking
# -----------------------------------------------------------------------------

def fig_multiday_compare(data, out_path):
    if "scenarios" not in data or "multiday" not in data:
        print("  (skipped: no multiday data)")
        return
    sc = data["scenarios"]; md = data["multiday"]
    robust_t, single_t = data["scenarios_labels"]
    t_robust = sc[~np.isnan(sc[:, 0]), 0]
    t_single = sc[~np.isnan(sc[:, 1]), 1]

    fig, axes = plt.subplots(1, 2, figsize=(15, 6))

    # Left: histogram
    ax = axes[0]
    bins = np.linspace(min(t_robust.min(), t_single.min()),
                       max(t_robust.max(), t_single.max()), 20)
    ax.hist(t_robust, bins=bins, alpha=0.6, color=ROBUST,
            label=f"T{robust_t} (robust)\nmean €{t_robust.mean():.0f}, "
                  f"P95 €{np.percentile(t_robust, 95):.0f}",
            edgecolor="white", linewidth=1.0)
    ax.hist(t_single, bins=bins, alpha=0.55, color=SINGLE,
            label=f"T{single_t} (single-day)\nmean €{t_single.mean():.0f}, "
                  f"P95 €{np.percentile(t_single, 95):.0f}",
            edgecolor="white", linewidth=1.0)
    ax.axvline(t_robust.mean(), color=ROBUST, linestyle="--", linewidth=1.5)
    ax.axvline(t_single.mean(), color=SINGLE, linestyle="--", linewidth=1.5)
    ax.set_xlabel("Daily vessel operating cost (€)")
    ax.set_ylabel("Number of days (out of 50 scenarios)")
    ax.set_title("Daily cost distributions", fontweight="bold")
    ax.legend(loc="upper right", framealpha=0.95, fontsize=9)
    ax.grid(alpha=0.3)

    # Right: top-10 ranking
    ax = axes[1]
    order = np.argsort(md[:, 5])
    top10 = md[order][:10]
    ys = np.arange(10)
    totals_m = top10[:, 5] / 1e6
    std_m    = top10[:, 2] * 300 / 1e6
    labels   = [f"T{int(t)}" for t in top10[:, 0]]
    best_t   = int(top10[0, 0])
    colors = []
    for t in top10[:, 0].astype(int):
        if t == best_t:    colors.append(ROBUST)
        elif t == single_t: colors.append(SINGLE)
        else:              colors.append("#6a8aa3")

    ax.barh(ys, totals_m, xerr=std_m, color=colors,
            edgecolor="white", linewidth=1.0,
            error_kw=dict(ecolor="#444", capsize=3, lw=1))
    ax.set_yticks(ys); ax.set_yticklabels(labels); ax.invert_yaxis()
    for i, t in enumerate(totals_m):
        ax.text(t + 0.02, i, f"€{t:.3f}M", va="center", fontsize=8.5)
    ax.set_xlabel("Expected annual cost (€M, ± 1 SD)")
    ax.set_title("Top 10 candidate sites by expected cost", fontweight="bold")
    xmin = totals_m.min() - 0.02; xmax = totals_m.max() + 0.05
    ax.set_xlim(xmin, xmax)
    ax.grid(axis="x", alpha=0.3)
    ax.legend(handles=[
        Line2D([0], [0], color=ROBUST, lw=8, label=f"Robust optimum (T{best_t})"),
        Line2D([0], [0], color=SINGLE, lw=8, label=f"Single-day optimum (T{single_t})"),
        Line2D([0], [0], color="#6a8aa3", lw=8, label="Other candidates"),
    ], loc="lower right", fontsize=8.5, framealpha=0.95)

    plt.tight_layout()
    plt.savefig(out_path, dpi=160, bbox_inches="tight")
    plt.close()
    print(f"  -> {out_path}")


# -----------------------------------------------------------------------------
# Figure 5: per-scenario comparison
# -----------------------------------------------------------------------------

def fig_multiday_scenarios(data, out_path):
    if "scenarios" not in data:
        print("  (skipped: no scenario data)")
        return
    sc = data["scenarios"]
    robust_t, single_t = data["scenarios_labels"]
    t_robust = sc[:, 0]; t_single = sc[:, 1]
    order = np.argsort(t_robust)
    rs = t_robust[order]; ss = t_single[order]
    x = np.arange(1, len(rs) + 1)

    fig, ax = plt.subplots(figsize=(14, 5.5))
    worse = ss > rs
    ax.fill_between(x, rs, ss, where=worse,
                    color=SINGLE, alpha=0.15,
                    label=f"T{single_t} worse than T{robust_t}")
    ax.fill_between(x, rs, ss, where=~worse,
                    color=ROBUST, alpha=0.15,
                    label=f"T{robust_t} worse than T{single_t}")
    ax.plot(x, rs, "o-", color=ROBUST, markersize=5, linewidth=1.5,
            label=f"T{robust_t} (robust)")
    ax.plot(x, ss, "s-", color=SINGLE, markersize=5, linewidth=1.5,
            label=f"T{single_t} (single-day opt)")

    n_wins = int(worse.sum())
    ax.set_xlabel(f"Scenario (sorted by T{robust_t} cost, ascending)")
    ax.set_ylabel("Daily vessel operating cost (€)")
    ax.set_title(f"Per-scenario comparison: T{robust_t} beats T{single_t} "
                 f"in {n_wins}/{len(rs)} scenarios\n"
                 f"T{robust_t} is more robust — lower mean AND lower tail risk",
                 fontweight="bold")
    ax.legend(loc="upper left", framealpha=0.95)
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_path, dpi=160, bbox_inches="tight")
    plt.close()
    print(f"  -> {out_path}")


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------

FIGURES = {
    "fig_dogger_main":        fig_dogger_main,
    "fig_dogger_costs":       fig_dogger_costs,
    "fig_multiday_map":       fig_multiday_map,
    "fig_multiday_compare":   fig_multiday_compare,
    "fig_multiday_scenarios": fig_multiday_scenarios,
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="../data")
    parser.add_argument("--out",  default="../figures")
    parser.add_argument("--only", choices=list(FIGURES.keys()), default=None,
                        help="generate just one figure")
    args = parser.parse_args()

    setup_style()
    data = load_data(args.data)
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)

    print(f"Generating figures in {out}/")
    keys = [args.only] if args.only else list(FIGURES.keys())
    for k in keys:
        FIGURES[k](data, out / f"{k}.png")


if __name__ == "__main__":
    main()
